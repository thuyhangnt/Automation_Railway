package Railway;

public class MyTicketPage extends GeneralPage {
	
	public boolean isMyTicketPageDisplayed() {
		return getTabMyTicket().isDisplayed();
	}

}
