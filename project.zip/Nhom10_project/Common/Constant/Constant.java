package Constant;

import org.openqa.selenium.WebDriver;

public class Constant {
	public static WebDriver WEBDRIVER;
	public static final String RAILWAY_URL = "http://railwayb2.somee.com";
	public static final String USERNAME = "ntth102223@gmail.com";
	public static final String PASSWORD = "thuyhang2205@@";
	
	public static final String USERNAME1 = "ngth.hang@gmail.com";
	public static final String PASSWORD1 = "hang2205";

}
