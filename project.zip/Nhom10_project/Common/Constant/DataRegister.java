package Constant;

public class DataRegister {
	public static final String EMAIL = "th.hang123456@gmail.com";
	public static final String PASSWORD = "thuyhang2205";
	public static final String ConfirmPasswordEMAIL = "thuyhang2205";
	public static final String PID = "220520027543";
	
	public static final String EMAIL1 = "ngth.hang@gmail.com";
	public static final String PASSWORD1= "hang2205";
	public static final String ConfirmPasswordEMAIL1= "hang2205";
	public static final String PID1 = "3576667699";
	
	public static final String EMAIL2 = "pnhu@gmail.com";
	public static final String PASSWORD2= "pnhuu2205";
	public static final String ConfirmPasswordEMAIL2= "pnhuu2205";
	public static final String PID2 = "8661295522";
}
