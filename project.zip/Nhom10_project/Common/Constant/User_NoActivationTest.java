package Constant;

public class User_NoActivationTest {
	public static final String EMAIL = "pnhu@gmail.com";
	public static final String PASSWORD = "pnhupnhu";
}
